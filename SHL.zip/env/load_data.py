import torch
import numpy as np


def load_fjs(lines, num_mas, num_opes):
    '''
    Load the local FJSP instance.
    '''
    flag = 0
    matrix_proc_time = torch.zeros(
        size=(num_opes, num_mas))  # 返回一个每个元素都是0、形状为size的矩阵。 加工时间矩阵 工序数*机器数
    matrix_pre_proc = torch.full(size=(num_opes, num_opes), dtype=torch.bool, fill_value=False)
    # 返回创建size维度大小的矩阵，里面元素全部填充为布尔类型  值表示工序之间的优先级 第n个工序加工完之后第n+1个工序才能开始 则矩阵中对应位置（n，n+1)=true
    matrix_cal_cumul = torch.zeros(size=(num_opes, num_opes)).int()
    # 32 位整型：dtype=torch.int32  每行的值表示对应工序所属工件的加工进度，未加工的工序对应值为1
    # 例如第一个工件有4个工序，则矩阵中对应位置（1,2）（1,3）（1,4）（2,3）（2,4）（3,4）为1
    nums_ope = []  # 每个工件的工序数
    opes_appertain = np.array([])  # 从左向右排列所有工序 该工序对应工件的编号值（0至num_jobs-1）
    num_ope_biases = []  # The id of the first operation of each job 从左向右排列所有工序  每个工件第一个工序所属位置的编号 （0，...，)
    # Parse data line by line
    for line in lines:
        # first line
        if flag == 0:
            flag += 1
        # last line
        elif line == "\n":
            break
        # other
        else:
            num_ope_bias = int(sum(nums_ope))  # The id of the first operation of this job
            num_ope_biases.append(num_ope_bias)
            # Detect information of this job and return the number of operations
            num_ope = edge_detec(line, num_ope_bias, matrix_proc_time, matrix_pre_proc,
                                 matrix_cal_cumul)  # 获得工件的工序数
            nums_ope.append(num_ope)  # 每个工件的工序数
            # nums_option = np.concatenate((nums_option, num_option))
            opes_appertain = np.concatenate((opes_appertain, np.ones(num_ope) * (
                    flag - 1)))  # 从左向右排列所有工序 该工序对应工件的编号（0至num_jobs-1）
            flag += 1
    matrix_ope_ma_adj = torch.where(matrix_proc_time > 0, 1, 0)  # 工序对应可加工机器值为1，否则为0
    # Fill zero if the operations are insufficient (for parallel computation)
    opes_appertain = np.concatenate((opes_appertain, np.zeros(num_opes - opes_appertain.size)))
    # num_opes 为并行计算时所有算例的最大工序数，当前算例工序数不足时其余位置填充为0

    matrix_ope_ope_adj = torch.where(matrix_pre_proc, 1, 0)
    matrix_ope_ope_adj = matrix_ope_ope_adj +matrix_ope_ope_adj.t()
    #工序-工序矩阵 (9)为（3）的0/1表示形式 且变换为对阵矩阵

    return matrix_proc_time, matrix_ope_ma_adj, matrix_pre_proc, matrix_pre_proc.t(), \
        torch.tensor(opes_appertain).int(), torch.tensor(num_ope_biases).int(), \
        torch.tensor(nums_ope).int(), matrix_cal_cumul,matrix_ope_ope_adj

# 共8个：(1)加工时间矩阵 shape:工序数*机器数 (2)工序是否可在机器上加工 可加工值为1，否则为0 shape:工序数*机器数
#       （3）工序之间的优先级 第n个工序加工完之后第n+1个工序才能开始 则矩阵中对应位置（n，n+1)=true  shape:工序数*工序数 (4)为（3）的转置矩阵
#        (5)工序对应工件的编号（0至工件数-1） (6)每个工件第一个工序所属位置的编号 （0，...，)
#        (7)每个工件的工序数             (8)工序所属工件的加工进度  (9)为（3）的0/1表示形式


def nums_detec(lines):
    '''
    Count the number of jobs, machines and operations 获得工件数  机器数  总工序数
    '''
    num_opes = 0
    for i in range(1, len(lines)):
        num_opes += int(lines[i].strip().split()[0]) if lines[i] != "\n" else 0
    line_split = lines[0].strip().split()
    num_jobs = int(line_split[0])
    num_mas = int(line_split[1])
    return num_jobs, num_mas, num_opes


def edge_detec(line, num_ope_bias, matrix_proc_time, matrix_pre_proc, matrix_cal_cumul):
    '''
    Detect information of a job
    '''
    line_split = line.split()
    flag = 0
    flag_time = 0
    flag_new_ope = 1
    idx_ope = -1
    num_ope = 0  # Store the number of operations of this job
    num_option = np.array(
        [])  # Store the number of processable machines for each operation of this job
    mac = 0
    for i in line_split:
        x = int(i)
        # The first number indicates the number of operations of this job
        if flag == 0:
            num_ope = x
            flag += 1
        # new operation detected
        elif flag == flag_new_ope:
            idx_ope += 1
            flag_new_ope += x * 2 + 1
            num_option = np.append(num_option, x)
            if idx_ope != num_ope - 1:
                matrix_pre_proc[idx_ope + num_ope_bias][idx_ope + num_ope_bias + 1] = True
            if idx_ope != 0:
                vector = torch.zeros(matrix_cal_cumul.size(0))
                vector[idx_ope + num_ope_bias - 1] = 1
                matrix_cal_cumul[:, idx_ope + num_ope_bias] = matrix_cal_cumul[:,
                                                              idx_ope + num_ope_bias - 1] + vector
            flag += 1
        # not proc_time (machine)
        elif flag_time == 0:
            mac = x - 1
            flag += 1
            flag_time = 1
        # proc_time
        else:
            matrix_proc_time[idx_ope + num_ope_bias][mac] = x
            flag += 1
            flag_time = 0
    return num_ope
